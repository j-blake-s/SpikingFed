import torch
import os
from torch.utils.data import DataLoader
from utils.training import train, test


# Args
from utils.argparser import get_args
args = get_args()


# Model
from model.snn import SNN
model = SNN().to(args.device)
print(f'Parameters: {model.params():,}')


# Data
from utils.dvs_data import DvsGesture
dataset_train = DvsGesture(os.path.join(args.data_path, "train.npz"))
dataset_test = DvsGesture(os.path.join(args.data_path, "test.npz"))

# from utils.data import load_data
# dataset_train, dataset_test,_,_ = load_data(args.data_path, T=16)


data_loader = torch.utils.data.DataLoader(
    dataset=dataset_train,
    batch_size=args.batch_size,
    shuffle=True,
    drop_last=True,
    pin_memory=True)

data_loader_test = torch.utils.data.DataLoader(
    dataset=dataset_test,
    batch_size=args.batch_size,
    shuffle=True,
    drop_last=True,
    pin_memory=True)


# Learning Tools
import lava.lib.dl.slayer as slayer
optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
error = slayer.loss.SpikeRate(true_rate=0.5, false_rate=0.05, reduction='mean').to(args.device)
classer = slayer.classifier.Rate.predict




# # Run
# torch.autograd.set_detect_anomaly(True)
for epoch in range(args.epochs):
  print(" "*50,end="\r")
  print(f'Epoch [{epoch+1}/{args.epochs}]')
  train_acc = train(model, data_loader, optimizer, error, classer, args)
  test_acc = test(model, data_loader_test, classer, args)
  print(f'\033[F\rEpoch [{epoch+1}/{args.epochs}] Training: {train_acc:.2%}\tValidation: {test_acc:.2%}              ')