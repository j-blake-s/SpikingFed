- This trains a spiking neural network on DvsGesture Dataset

- Run "python train.py --device cuda:1" to train the spiking neural network

- For a list of packages needed to run the network, take a look at reqs.txt.

- You can install the necessary packages with "pip install -r reqs.txt"