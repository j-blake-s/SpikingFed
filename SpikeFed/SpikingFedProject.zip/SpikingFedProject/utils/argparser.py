
import argparse


def get_args():
    parser = argparse.ArgumentParser('Cifar10DVS')

    parser.add_argument('--device', type=str, default="cpu")
    parser.add_argument('--data_path', type=str, default='/data/DvsGesture/t16')
    parser.add_argument('--batch_size', type=int, default=16)
    parser.add_argument('--lr', type=float, default=0.0001)
    parser.add_argument('--epochs', type=int, default=200)

    arguments = parser.parse_args()
    return arguments
